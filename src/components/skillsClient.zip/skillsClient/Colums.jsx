import { FaCss3Alt, FaPython } from "react-icons/fa";
import {
  SiReact, SiNextdotjs, SiJavascript, SiTailwindcss, SiRedux,
  SiNodedotjs, SiExpress, SiMongodb,
  SiGit, SiDocker, SiFirebase, SiPrisma, SiVercel, SiFigma,
  SiTypescript,
  SiFramework,
} from "react-icons/si";

export const columns = [
  {
    title: "Frontend & UI/UX",
    subtitle: "Building fast, interactive user interfaces",
    skills: [
      { name: "Next.js",      icon: <SiNextdotjs />,    percentage: "90%", color: "linear-gradient(90deg,#00d4ff,#0072ff)", iconColor: "#ffffff" },
      { name: "React",        icon: <SiReact />,         percentage: "95%", color: "linear-gradient(90deg,#00d4ff,#61dafb)", iconColor: "#61DAFB" },
      { name: "Tailwind CSS", icon: <SiTailwindcss />,   percentage: "98%", color: "linear-gradient(90deg,#00d4ff,#06b6d4)", iconColor: "#06B6D4" },
      { name: "CSS", icon: <FaCss3Alt />,   percentage: "92%", color: "linear-gradient(90deg,#00d4ff,#ebcc34)", iconColor: "#06B6D4" },
      { name: "Redux",        icon: <SiRedux />,         percentage: "80%", color: "linear-gradient(90deg,#764abc,#a78bfa)", iconColor: "#764ABC" },
      { name: "UI Component Libraries",        icon: <SiFramework />,         percentage: "80%", color: "linear-gradient(90deg,#b3c5c7,#6cb5bd)", iconColor: "#764ABC" },
    ],
  },
  {
    title: "Backend & Auth",
    subtitle: "Designing scalable server-side systems",
    skills: [
      { name: "Node.js",      icon: <SiNodedotjs />,     percentage: "90%", color: "linear-gradient(90deg,#00d4ff,#339933)", iconColor: "#339933" },
      { name: "MongoDB",      icon: <SiMongodb />,       percentage: "85%", color: "linear-gradient(90deg,#00d4ff,#47a248)", iconColor: "#47A248" },
      { name: "Express",      icon: <SiExpress />,       percentage: "88%", color: "linear-gradient(90deg,#00d4ff,#aaaaaa)", iconColor: "#aaaaaa" },
      { name: "Firebase",     icon: <SiFirebase />,      percentage: "80%", color: "linear-gradient(90deg,#ffca28,#ff6f00)", iconColor: "#FFCA28" },
      { name: "BetterAuth",   icon: <SiFirebase />,      percentage: "95%", color: "linear-gradient(90deg,#2c9ec2,#ff6f00)", iconColor: "#FFCA28" },
      { name: "Prisma",       icon: <SiPrisma />,        percentage: "70%", color: "linear-gradient(90deg,#00d4ff,#5a67d8)", iconColor: "#a5b4fc" },
    ],
  },
  {
    title: "Tools & Platforms",
    subtitle: "DevOps, cloud, and productivity tools",
    skills: [
      { name: "Git",          icon: <SiGit />,           percentage: "92%", color: "linear-gradient(90deg,#f05032,#ff7a5c)", iconColor: "#F05032" },
      { name: "Vercel",       icon: <SiVercel />,        percentage: "90%", color: "linear-gradient(90deg,#00d4ff,#ffffff)", iconColor: "#ffffff" },
      { name: "Docker",       icon: <SiDocker />,        percentage: "78%", color: "linear-gradient(90deg,#2496ed,#00d4ff)", iconColor: "#2496ED" },
      { name: "Figma",        icon: <SiFigma />,         percentage: "85%", color: "linear-gradient(90deg,#f24e1e,#ff7262)", iconColor: "#F24E1E" },
    ],
  },
  {
    title: "Core & Language",
    subtitle: "Developing the logic and fundamental structure of an application.",
    skills: [
      { name: "JavaScript",   icon: <SiJavascript />,    percentage: "95%", color: "linear-gradient(90deg,#f7df1e,#fbbf24)", iconColor: "#F7DF1E" },
      { name: "TypeScript (exploring)",   icon: <SiTypescript />,    percentage: "50%", color: "linear-gradient(90deg,#f7df1e,#fbbf24)", iconColor: "#F7DF1E" },
      { name: "Python (exploring)",   icon: <FaPython />,    percentage: "50%", color: "linear-gradient(90deg,#f7df1e,#fbbf24)", iconColor: "#F7DF1E" },
    ],
  },
];